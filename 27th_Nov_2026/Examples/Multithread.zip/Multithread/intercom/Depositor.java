package com.bupa.intercom;
public class Depositor extends Thread {

    BankAccount account;

    public Depositor(BankAccount account) {

        this.account = account;
    }

    @Override
    public void run() {

        account.deposit(10000);
    }
}