package com.bupa.intercom;
public class Customer extends Thread {

    BankAccount account;

    public Customer(BankAccount account, String name) {

        super(name);
        this.account = account;
    }

    @Override
    public void run() {

        account.withdraw(5000);
    }
}