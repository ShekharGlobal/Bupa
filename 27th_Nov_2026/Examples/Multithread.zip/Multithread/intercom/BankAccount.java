package com.bupa.intercom;
public class BankAccount {

    int balance = 0;

    public synchronized void withdraw(int amount) {

        String name = Thread.currentThread().getName();

        while (balance < amount) {

            System.out.println(name + " is waiting");

            try {
                wait();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return;
            }
        }

        balance = balance - amount;

        System.out.println(name + " withdrew " + amount);
        System.out.println("Balance: " + balance);
    }

    public synchronized void deposit(int amount) {

        balance = balance + amount;

        System.out.println("Deposited: " + amount);

        notifyAll();
    }
}