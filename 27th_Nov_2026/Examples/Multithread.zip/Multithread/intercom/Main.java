package com.bupa.intercom;
public class Main {

    public static void main(String[] args)
            throws InterruptedException {

        BankAccount account = new BankAccount();

        Customer t1 = new Customer(account, "Customer 1");
        Customer t2 = new Customer(account, "Customer 2");

        Depositor t3 = new Depositor(account);

        t1.start();
        t2.start();

        Thread.sleep(2000);

        t3.start();
    }
}