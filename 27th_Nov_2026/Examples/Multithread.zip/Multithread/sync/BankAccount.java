package com.bupa.sync;

public class BankAccount {

	int balance = 10000;

	public synchronized void withdraw(int amount) {

		String name = Thread.currentThread().getName();

		if (balance >= amount) {

			System.out.println(name + " is withdrawing " + amount);

			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				Thread.currentThread().interrupt();
				return;
			}

			balance = balance - amount;

			System.out.println("Remaining balance: " + balance);

		} else {
			System.out.println(name + ": Insufficient balance");
		}
	}
}