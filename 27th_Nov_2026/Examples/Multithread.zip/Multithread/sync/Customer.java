package com.bupa.sync;
public class Customer extends Thread {

    BankAccount account;
    int amount;

    public Customer(BankAccount account, int amount, String name) {

        super(name);
        this.account = account;
        this.amount = amount;
    }

    @Override
    public void run() {

        account.withdraw(amount);
    }
}