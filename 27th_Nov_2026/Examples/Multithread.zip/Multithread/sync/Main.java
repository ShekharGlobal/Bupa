package com.bupa.sync;
public class Main {

    public static void main(String[] args) {

        BankAccount account = new BankAccount();

        Customer t1 = new Customer(account, 7000, "Customer 1");
        Customer t2 = new Customer(account, 7000, "Customer 2");

        t1.start();
        t2.start();
    }
}